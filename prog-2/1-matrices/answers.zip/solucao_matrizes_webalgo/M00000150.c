#include <stdio.h>

#define N 5

void main(){
  int mat[N][N];
  int i, j, soma;
  
  for(i=0; i<N; i++){
      for(j=0; j<N; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }

  soma = 0;
  for(i=0, j=N-1; i<N; i++, j--){
      soma += mat[i][j];
  }
    
  printf("Soma: %d\n", soma);
}

