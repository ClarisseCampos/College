#include <stdio.h>
#include <stdio_ext.h>

//---------------------------------------------------
#define N 100

//---------------------------------------------------
int numchrtimes(char str1[N]){
	int i, cont = 0;
	for(i=0; str1[i]!='\0'; i++){
		if (str1[i] >='0' && str1[i] <='9'){
			cont++;
		} 
	}
	return cont;
}
//--------------------------------------------------
int main(){
	char str1[N];
	
	printf("Digite a string:\n");
	gets(str1);

	printf("Vezes: %d\n", numchrtimes(str1)); 
}
//--------------------------------------------------

