#include <stdio.h>

/*-----------------------------------------------------------*/
int valido(int h, int m, int s){
	if ( h>=0 && h<24 && m>=0 && m<60 && s>=0 && s<60){
		return 1;
	}
	else{
		return 0;
	}	   
	
}

/*-----------------------------------------------------------*/
int main(){
	int h, m, s;
	
	printf("Digite o horario:\n");
	scanf("%d %d %d", &h, &m, &s);
	
	if ( valido(h, m, s) ){
		printf("Horario valido\n");
	}
	else{
		printf("Horario invalido\n");
	}
}
/*-----------------------------------------------------------*/
