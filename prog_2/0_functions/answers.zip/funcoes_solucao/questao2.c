#include <stdio.h>

/*-----------------------------------------------------------*/
int maior(int ano){
	return  ano>=18? 1: 0;
}

/*-----------------------------------------------------------*/
int main(){
	int ano;
	
	printf("Digite o ano de nascimento:\n");
	scanf("%d", &ano);
	
	if ( maior(ano) ){
		printf("Maior de idade\n");
	}
	else{
		printf("Menor de idade\n");
	}
}
/*-----------------------------------------------------------*/
