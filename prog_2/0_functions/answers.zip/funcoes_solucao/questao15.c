#include <stdio.h>
#include <string.h>
#include <ctype.h>

/*-----------------------------------------------------------------*/
int palindromo(char str[50]){
	int i, f;

	for(i=0, f=strlen(str)-1; i<f; i++, f--){
		if (toupper(str[i]) != toupper(str[f]) ){
			return 0;			
		}
	}	 
	return 1;
}

/*-----------------------------------------------------------------*/
void main(){
	char palavra[50];

	printf("Digite a palavra:\n");
	scanf("%s", palavra);

	if ( palindromo(palavra) ){
		printf("A palavra %s e palindromo\n", palavra);
	}
	else{
		printf("A palavra %s nao e palindromo\n", palavra);
	}
}
/*-----------------------------------------------------------------*/
