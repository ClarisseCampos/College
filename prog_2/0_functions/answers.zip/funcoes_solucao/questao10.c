#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 5

/*-----------------------------------------------------------*/
void gera_matriz(int mat[N][N]){
	int i, j;
	srand(time(NULL));
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			mat[i][j] = rand() % 10;
		}
	}
} 

/*-----------------------------------------------------------*/
void escreve_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("% 4d", mat[i][j]);
		}
		printf("\n");
	}
}
/*-----------------------------------------------------------*/
int soma_linha(int mat[N][N], int lin){
	int j, s = 0;
	for(j=0; j<N; j++){
		s += mat[lin][j];
	}
	return s;
}
/*-----------------------------------------------------------*/
int main(){
	int mat[N][N], lin;
	
	gera_matriz(mat);
	escreve_matriz(mat);
	
	printf("Digite a linha:\n");
	scanf("%d", &lin);
	
	printf("Soma da Linha: %d\n", soma_linha(mat, lin));
}
/*-----------------------------------------------------------*/
