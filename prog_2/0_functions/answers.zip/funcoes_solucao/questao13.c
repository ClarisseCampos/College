#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 5

/*-----------------------------------------------------------*/
void escreve_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("% 4d", mat[i][j]);
		}
		printf("\n");
	}
}
/*-----------------------------------------------------------*/
int diagonal(int mat[N][N]){
      int i, j;
      for(i=0; i<N; i++){
              for(j=0; j<N; j++){
                  if ((i==j && mat[i][j]!=1) || (i!=j && mat[i][j]!=0)){
                        return 0; 
                  }
              }
      }
}
/*-----------------------------------------------------------*/
int main(){
	int mat[N][N] = { {1, 0, 0, 0, 0}, {0, 1, 0, 0, 0}, {0, 0, 1, 0, 0}, {0, 0, 0, 1, 0}, {0, 0, 0, 0, 1}};
	
	escreve_matriz(mat);
	
	if ( diagonal(mat) ){
	      printf("A matriz e diagonal\n");
	}
	else{
	      printf("A matriz nao e diagonal\n");
	}
}
/*-----------------------------------------------------------*/
