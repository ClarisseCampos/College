#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 5

/*-----------------------------------------------------------*/
void gera_matriz(int mat[N][N]){
	int i, j;
	srand(time(NULL));
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			mat[i][j] = rand() % 10;
		}
	}
} 

/*-----------------------------------------------------------*/
void escreve_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("% 4d", mat[i][j]);
		}
		printf("\n");
	}
}
/*-----------------------------------------------------------*/
int soma_diagonal_principal(int mat[N][N]){
	int i, s = 0;
	for(i=0; i<N; i++){
		s += mat[i][i];
	}
	return s;
}
/*-----------------------------------------------------------*/
int main(){
	int mat[N][N];
	
	gera_matriz(mat);
	escreve_matriz(mat);
	
	printf("Soma da diagonal principal: %d\n", soma_diagonal_principal(mat));
}
/*-----------------------------------------------------------*/
