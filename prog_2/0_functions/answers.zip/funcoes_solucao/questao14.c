#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 5

/*-----------------------------------------------------------*/
void escreve_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("% 4d", mat[i][j]);
		}
		printf("\n");
	}
}
/*-----------------------------------------------------------*/
int tipo(int mat[N][N]){
        int i, j, acima, abaixo, diagonal;
      
        acima = abaixo = diagonal = 0;
  
        for(i=0; i<N; i++){
            for(j=0; j<N; j++){
                if ( i==j && mat[i][j] != 0){
                    diagonal++;
                }
                else if ( i < j && mat[i][j] != 0){
                    acima++;
                }
                else if (mat[i][j] != 0){
                    abaixo++;
                }
            }
        }
    
        if ( diagonal && !acima && !abaixo){
            return 0;
        }
        else if ( !abaixo && acima){
            return 1;
        }
        else if ( !acima && abaixo){
            return 2;
        }
        else{
            return 3;
        }
}
/*-----------------------------------------------------------*/
int main(){
	//int mat[N][N] = { {1, 0, 0, 0, 0}, {0, 1, 0, 0, 0}, {0, 0, 1, 0, 0}, {0, 0, 0, 1, 0}, {0, 0, 0, 0, 1}};
	//int mat[N][N] = { {0, 1, 2, 0, 3}, {0, 0, 2, 0, 1}, {0, 0, 0, 5, 0}, {0, 0, 0, 0, 5}, {0, 0, 0, 0, 0}};
	//int mat[N][N] = { {0, 0, 0, 0, 0}, {1, 0, 0, 0, 0}, {0, 2, 0, 0, 0}, {1, 2, 4, 0, 0}, {2, 0, 3, 4, 0}};
	int mat[N][N] = { {0, 0, 2, 0, 5}, {1, 0, 0, 0, 0}, {0, 2, 0, 2, 7}, {1, 2, 4, 0, 2}, {2, 0, 3, 4, 0}};
	
	escreve_matriz(mat);
	printf("Tipo da matriz: %d\n", tipo(mat));
	
}
/*-----------------------------------------------------------*/
