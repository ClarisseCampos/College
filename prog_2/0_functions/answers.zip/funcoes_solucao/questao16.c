#include <stdio.h>
//---------------------------------------------------
#define N 100
//---------------------------------------------------
int numchrtimes(char str[N]){
	int i, cont = 0;
	for(i=0; str[i]!='\0'; i++){
		if (str[i] >='0' && str[i] <='9'){
			cont++;
		} 
	}
	return cont;
}
//--------------------------------------------------
int main(){
	char str[N];
	
	printf("Digite a string:\n");
	gets(str);

	printf("Vezes: %d\n", numchrtimes(str)); 
}
//--------------------------------------------------

