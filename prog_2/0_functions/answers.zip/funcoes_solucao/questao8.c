#include <stdio.h>

/*-----------------------------------------------------------*/
int conta_divisores(int n){
	int i, cont = 0;
	
	for(i=1; i<=n; i++){
		if ( n % i == 0){
			cont++;
		}
	}
	return cont;
}

/*-----------------------------------------------------------*/
int main(){
	int n;
	
	printf("Digite o valor:\n");
	scanf("%d", &n);
	
	printf("Divisores: %d\n", conta_divisores(n));
}
/*-----------------------------------------------------------*/
