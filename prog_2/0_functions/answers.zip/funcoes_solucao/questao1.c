#include <stdio.h>

/*-----------------------------------------------------------*/
int multiplicacao(int a, int b){
	return a * b;
}

/*-----------------------------------------------------------*/
int main(){
	int a, b;
	
	printf("Digite os 2 valores:\n");
	scanf("%d %d", &a, &b);
	
	printf("Resultado: %d\n", multiplicacao(a, b));

}
/*-----------------------------------------------------------*/
