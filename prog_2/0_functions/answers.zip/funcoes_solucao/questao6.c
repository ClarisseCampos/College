#include <stdio.h>

/*-----------------------------------------------------------*/
int diferenca(int h1, int m1, int s1, int h2, int m2, int s2){
	return (h1*3600 + 60*m1 + s1) - (h2*3600 + 60*m2 + s2);
	 
}

/*-----------------------------------------------------------*/
int main(){
	int h1, m1, s1, h2, m2, s2;
	
	printf("Digite o primeiro horario:\n");
	scanf("%d %d %d", &h1, &m1, &s1);
	
	printf("Digite o segundo horario:\n");
	scanf("%d %d %d", &h2, &m2, &s2);
	
	printf("Diferenca: %d\n", diferenca(h1, m1, s1, h2, m2, s2));
	
}
/*-----------------------------------------------------------*/
