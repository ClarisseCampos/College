#include <stdio.h>

/*-----------------------------------------------------------*/
float area(float base, float altura){
	return base * altura;
}

/*-----------------------------------------------------------*/
int main(){
	float base, altura;
	
	printf("Digite os valores da base e altura:\n");
	scanf("%f %f", &base, &altura);
	
	printf("Area: %.2f\n", area(base, altura));

}
/*-----------------------------------------------------------*/
