#include <stdio.h>

/*-----------------------------------------------------------*/
int fatorial(int n){
	int i, f = 1;
	
	for(i=1; i<=n; i++){
		f *= i;
	}
	return f;
	 
}

/*-----------------------------------------------------------*/
int main(){
	int n;
	
	printf("Digite o valor:\n");
	scanf("%d", &n);
	
	printf("Fatorial: %d\n", fatorial(n));
}
/*-----------------------------------------------------------*/
