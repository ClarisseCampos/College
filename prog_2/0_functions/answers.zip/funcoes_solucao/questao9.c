#include <stdio.h>
#include <math.h>
/*-----------------------------------------------------------*/
int primo(int n){
	int i, cont = 0;
	
	if ( n< 2){
		return 0;
	}
	
	for(i=2; i<=sqrt(n); i++){
		if ( n % i == 0){
			return 0;
		}
	}
	
	return 1;
}

/*-----------------------------------------------------------*/
int main(){
	int n;
	
	printf("Digite o valor:\n");
	scanf("%d", &n);
	
	if ( primo(n) ){
		printf("O valor %d eh primo\n", n);
	}
	else{
		printf("O valor %d nao eh primo\n", n);
	}
}
/*-----------------------------------------------------------*/
