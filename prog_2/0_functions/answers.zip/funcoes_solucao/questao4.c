#include <stdio.h>

/*-----------------------------------------------------------*/
float media(float n1, float n2, float n3){
	if ( n1 == 0 || n2 == 0 || n3 == 0){
		return 0;
	}
	else{
		return 3 / (1/n1 + 1/n2 + 1/n3);
	}
}

/*-----------------------------------------------------------*/
int main(){
	float n1, n2, n3;
	
	printf("Digite as 3 notas:\n");
	scanf("%f %f %f", &n1, &n2, &n3);
	
	printf("Media: %.2f\n", media(n1, n2, n3));

}
/*-----------------------------------------------------------*/
